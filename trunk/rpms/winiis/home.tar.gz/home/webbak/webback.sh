#!/bin/bash
#by Canihc 20120801
webpath=/home/www
webback=/home/webbak
back_dir=$(date +%Y%m%d)
ftphost=you ftp ip
ftpuser=you ftp user
ftppwd=you ftp pass
exclude='-x*.tar -x*.TAR -x*.tar.gz -x*.TAR.GZ -x*.zip -x*.ZIP -x*.rar -x*.RAR -x*.log -x*.LOG -x*.xls -x*.XLS -x*.jpg -x*.JPG -x*.Jpg -x*.jpeg -x*.Jpeg -x*.JPEG -x*.gif -x*.Gif -x*.GIF -x*.png -x*.Png -x*.PNG -xsess_* -xSESS_* -x*.7z'
###########################################################
for website in `ls $webpath`
do
rar $exclude u -as "$webback/${website}.rar" "$webpath/${website}/wwwroot"
cd "$webback"
ftp_upload()
{
cd "$webback"
ftp -v -n "$ftphost" << END
user "$ftpuser" "$ftppwd"
type binary
mkdir "$back_dir"
cd "$back_dir"
put "${website}.rar"
bye
END
}
ftp_upload
done
exit
