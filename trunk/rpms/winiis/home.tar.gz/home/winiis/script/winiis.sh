#!/bin/bash
#!/bin/bash
##########################################
# winiis_lamp | SOURCE CODE | 35ZH.COM   #
# -------------------------------------- #
# Written    by   HuangYunJian           #
# -------------------------------------- #
# Last modified time: 2013-01-24 15:08   #
##########################################

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

## Check user permissions ##
if [ $(id -u) != "0" ]; then
	echo "Error: NO PERMISSION! Please login as root to run this script again."
	exit 1
fi

## Start ##
clear
echo ""
echo -e "\033[41;37m **************************************** \033[0m"
echo -e "\033[41;37m *  winiis Manager for winiis              * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *  Website: http://www.35zh.com        * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m **************************************** \033[0m"
echo ""
echo ""
echo "+--------+-------------------------------+       "
echo -e "      | \033[41;37m 1 \033[0m | Start winiis  "
echo "+--------+-------------------------------+"
echo -e "      | \033[41;37m 2 \033[0m | Stop winiis   "
echo "+--------+-------------------------------+"
echo -e "      | \033[41;37m 3 \033[0m | Reload winiis "
echo "+--------+-------------------------------+"
echo ""
read -p " Choose ( 1/2/3 ): " choose
echo ""

if [ "$choose" = "1" ]; then
	/home/winiis/winiisagent/start
	echo -e "\033[41;37m winiis start ok \033[0m"
elif [ "$choose" = "2" ]; then
/home/winiis/winiisagent/stop
echo -e "\033[41;37m winiis stop ok \033[0m"
elif [ "$choose" = "3" ]; then
/home/winiis/winiisagent/restart
echo -e "\033[41;37m winiis restart ok \033[0m"
fi
