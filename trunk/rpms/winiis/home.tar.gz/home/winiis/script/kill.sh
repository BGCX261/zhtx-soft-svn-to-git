#!/bin/bash
killall mysqld
killall httpd
killall pure-ftpd
killall winiisagent
echo -e "\033[41;37m mysqld kill \033[0m"
echo -e "\033[41;37m httpd kill \033[0m"
echo -e "\033[41;37m pure-ftpd kill \033[0m"
echo -e "\033[41;37m winiisagent kill \033[0m"
