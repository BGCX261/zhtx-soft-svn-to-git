#!/bin/bash
#!/bin/bash
##########################################
# winiis_lamp | SOURCE CODE | 35ZH.COM   #
# -------------------------------------- #
# Written    by   HuangYunJian           #
# -------------------------------------- #
# Last modified time: 2013-01-24 15:08   #
##########################################

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

## Check user permissions ##
if [ $(id -u) != "0" ]; then
	echo "Error: NO PERMISSION! Please login as root to run this script again."
	exit 1
fi

#!/bin/bash
mysqlpass=`grep "MysqlPass" /home/winiis/winiisagent/winiisagent.xml |awk -F "value" '{print $2}' |awk -F '"' '{print $2}'`
mysqldump=/usr/local/mysql/bin/mysqldump
mysql=/usr/local/mysql/bin/mysql

## Start ##
clear
echo ""
echo -e "\033[41;37m **************************************** \033[0m"
echo -e "\033[41;37m *  mysql Manager import and export     * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *  Website: http://www.35zh.com        * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m **************************************** \033[0m"
echo ""
echo ""
echo "+--------+-------------------------------+     "
echo -e "      | \033[41;37m 1 \033[0m | IMPORT database  "
echo "+--------+-------------------------------+"
echo -e "      | \033[41;37m 2 \033[0m | export database "
echo "+--------+-------------------------------+"
echo ""
read -p " Choose ( 1/2 ): " choose
echo ""

if [ "$choose" = "1" ]; then
	echo -e "\033[41;37m Please enter the database \033[0m"
	read -p "Pleas enter database:" database
	read -p "pleas enter database sqlfile:" sqlfile
	$mysql -uroot -p$mysqlpass $database < $sqlfile 
	echo -e "\033[41;37m database:$database import ok \033[0m"
elif [ "$choose" = "2" ]; then
        echo -e "\033[41;37m Please enter the database \033[0m"
        read -p "Pleas enter database:" database
        $mysqldump -uroot -p$mysqlpass $database --skip-lock-table > ${database}_$(date +%Y-%m-%d).sql
        echo -e "\033[41;37m database:$database export ok \033[0m"
fi
