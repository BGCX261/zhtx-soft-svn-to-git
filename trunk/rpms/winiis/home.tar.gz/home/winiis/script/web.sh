#!/bin/bash
#!/bin/bash
##########################################
# winiis_lamp | SOURCE CODE | 35ZH.COM   #
# -------------------------------------- #
# Written    by   HuangYunJian           #
# -------------------------------------- #
# Last modified time: 2013-01-24 15:08   #
##########################################

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

## Check user permissions ##
if [ $(id -u) != "0" ]; then
	echo "Error: NO PERMISSION! Please login as root to run this script again."
	exit 1
fi

## Start ##
clear
echo ""
echo -e "\033[41;37m **************************************** \033[0m"
echo -e "\033[41;37m *  HTTPD Manager for winiis              * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m *  Website: http://www.35zh.com        * \033[0m"
echo -e "\033[41;37m *                                      * \033[0m"
echo -e "\033[41;37m **************************************** \033[0m"
echo ""
echo ""
echo "+--------+-------------------------------+     "
echo -e "      | \033[41;37m 1 \033[0m | Start WEB(httpd)  "
echo "+--------+-------------------------------+"
echo -e "      | \033[41;37m 2 \033[0m | Stop WEB(httpd)"
echo "+--------+-------------------------------+"
echo -e "      | \033[41;37m 3 \033[0m | Reload WEB(httpd) "
echo "+--------+-------------------------------+"
echo ""
read -p " Choose ( 1/2/3 ): " choose
echo ""

if [ "$choose" = "1" ]; then
	/usr/local/apache/bin/apachectl -k start
	echo -e "\033[41;37m httpd start ok \033[0m"
elif [ "$choose" = "2" ]; then
/usr/local/apache/bin/apachectl -k stop
echo -e "\033[41;37m httpd stop ok \033[0m"
elif [ "$choose" = "3" ]; then
/usr/local/apache/bin/apachectl -k restart
echo -e "\033[41;37m httpd restart ok \033[0m"
fi
