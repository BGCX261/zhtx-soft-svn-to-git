#!/bin/bash
/etc/init.d/mysqld start
/etc/init.d/httpd start
/home/winiis/pureftpd/start
/home/winiis/winiisagent/start >/dev/null 2>&1
echo -e "\033[41;37m mysqld start ok \033[0m"
echo -e "\033[41;37m httpd start ok \033[0m"
echo -e "\033[41;37m pureftpd start ok \033[0m"
echo -e "\033[41;37m winiisagent start ok \033[0m"
