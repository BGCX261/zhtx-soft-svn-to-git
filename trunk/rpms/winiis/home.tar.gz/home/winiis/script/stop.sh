#!/bin/bash
/etc/init.d/mysqld stop
/etc/init.d/httpd stop
/home/winiis/pureftpd/stop
/home/winiis/winiisagent/stop >/dev/null 2>&1
echo -e "\033[41;37m mysqld stop \033[0m"
echo -e "\033[41;37m httpd stop \033[0m"
echo -e "\033[41;37m pure-ftpd stop \033[0m"
echo -e "\033[41;37m winiisagent stop \033[0m"
