#!/bin/bash
/etc/init.d/mysqld restart
/etc/init.d/httpd restart
/home/winiis/pureftpd/restart
/home/winiis/winiisagent/restart >/dev/null 2>&1
echo "mysqld restart ok"
echo "httpd restart ok"
echo "pureftpd restart ok"
echo "winiisagent restart ok"
